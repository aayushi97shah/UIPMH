int add_int(int,int);
float add_float(float,float);
int sub_int(int,int);
float sub_float(float,float);
int mul_int(int,int);
float mul_float(float,float);
