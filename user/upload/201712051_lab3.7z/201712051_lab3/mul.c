int mul_int(int a,int b)
{
	return a*b;
}

float mul_float(float a,float b)
{
	return a*b;
}
