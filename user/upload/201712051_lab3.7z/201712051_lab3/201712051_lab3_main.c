#include<stdio.h>
#include"myheader.h"
int main()
{

printf("\naddition of 2 integer number is :%d",add_int(100,20));
printf("\naddition of 2 float number is :%f",add_float(100,20));
printf("\nsubtraction of 2 integer number is :%d",sub_int(100,20));
printf("\nsubtraction of 2 float number is :%f",sub_float(100,20));
printf("\nmultiplication of 2 integer number is :%d",mul_int(100,20));
printf("\nmultiplication of 2 float number is :%f",mul_float(100,20));

return 0;
}
