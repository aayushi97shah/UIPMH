int add_int(int a,int b)
{
	return a+b;
}

float add_float(float a,float b)
{
	return a+b;
}
