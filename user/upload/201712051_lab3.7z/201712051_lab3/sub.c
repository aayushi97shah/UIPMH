int sub_int(int a,int b)
{
	return a-b;
}

float sub_float(float a,float b)
{
	return a-b;
}
